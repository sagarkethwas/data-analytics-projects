import streamlit as st
import pickle
import numpy as np

with open("crop_model.pkl", "rb") as f:
    model = pickle.load(f)

st.title("🌾 Crop Prediction System")

N = st.number_input("Nitrogen")
P = st.number_input("Phosphorus")
K = st.number_input("Potassium")
temp = st.number_input("Temperature")
humidity = st.number_input("Humidity")
ph = st.number_input("pH")
rainfall = st.number_input("Rainfall")

if st.button("Predict Crop"):
    data = np.array([[N, P, K, temp, humidity, ph, rainfall]])
    prediction = model.predict(data)
    st.success(f"Recommended Crop: {prediction[0]}")
